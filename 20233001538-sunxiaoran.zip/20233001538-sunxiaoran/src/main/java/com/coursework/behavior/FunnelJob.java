package com.coursework.behavior;

import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;
import org.apache.hadoop.mapreduce.Reducer;

import java.io.IOException;
import java.util.HashSet;
import java.util.Set;

/**
 * 维度4：购买转化漏斗
 *
 * 思路：统计有过 点击 / 加购 / 收藏 / 购买 行为的“去重用户数”，
 * 漏斗一般是 点击用户数 → 加购用户数 → 购买用户数 逐级递减，
 * 由此可计算转化率（如 购买用户数 / 点击用户数）。
 *
 * 关键点：这里统计的是“用户数”而非“行为次数”，需要按用户去重。
 * Map：  输出 (行为类型, 用户ID)
 * Reduce：对每种行为类型，用 HashSet 统计不重复的用户数
 *
 * 说明：在 reduce 端用 HashSet 去重，逻辑直观、适合课程设计的数据规模。
 * 若数据极大，可改用 Map 端先按 (行为+用户) 去重等优化手段。
 */
public class FunnelJob {

    public static class FunnelMapper extends Mapper<Object, Text, Text, Text> {
        private final Text outKey = new Text();
        private final Text outVal = new Text();

        @Override
        protected void map(Object key, Text value, Context context)
                throws IOException, InterruptedException {
            BehaviorRecord r = BehaviorRecord.parse(value.toString());
            if (!r.valid) return;
            outKey.set(r.behavior);     // pv / cart / fav / buy
            outVal.set(r.userId);
            context.write(outKey, outVal);
        }
    }

    public static class FunnelReducer extends Reducer<Text, Text, Text, LongWritable> {
        @Override
        protected void reduce(Text key, Iterable<Text> values, Context context)
                throws IOException, InterruptedException {
            Set<String> users = new HashSet<>();
            for (Text v : values) {
                users.add(v.toString());   // 去重用户
            }
            context.write(key, new LongWritable(users.size()));
        }
    }
}
