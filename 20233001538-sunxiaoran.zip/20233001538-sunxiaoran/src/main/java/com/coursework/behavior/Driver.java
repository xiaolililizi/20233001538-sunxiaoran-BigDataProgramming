package com.coursework.behavior;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;

/**
 * 主驱动类
 *
 * 用法：
 *   hadoop jar hadoop-userbehavior.jar com.coursework.behavior.Driver <task> <input> <output>
 *
 * task 取值：
 *   topitems  - 维度1：热门商品 TOP10
 *   behavior  - 维度2：用户行为类型分布
 *   hourly    - 维度3：每小时活跃度分布
 *   funnel    - 维度4：购买转化漏斗（去重用户数）
 *
 * 例如：
 *   hadoop jar ... Driver topitems /userbehavior/input /userbehavior/output/topitems
 */
public class Driver {

    public static void main(String[] args) throws Exception {
        if (args.length != 3) {
            System.err.println("用法: Driver <topitems|behavior|hourly|funnel> <input> <output>");
            System.exit(1);
        }

        String task = args[0];
        String input = args[1];
        String output = args[2];

        Configuration conf = new Configuration();
        Job job = Job.getInstance(conf, "UserBehavior-" + task);
        job.setJarByClass(Driver.class);

        switch (task) {
            case "topitems":
                job.setMapperClass(TopItemsJob.TopItemsMapper.class);
                job.setReducerClass(TopItemsJob.TopItemsReducer.class);
                job.setMapOutputKeyClass(Text.class);
                job.setMapOutputValueClass(IntWritable.class);
                job.setOutputKeyClass(Text.class);
                job.setOutputValueClass(LongWritable.class);
                job.setNumReduceTasks(1);   // 必须为1，保证全局TOP10
                break;

            case "behavior":
                job.setMapperClass(BehaviorDistJob.BehaviorDistMapper.class);
                job.setReducerClass(BehaviorDistJob.BehaviorDistReducer.class);
                job.setMapOutputKeyClass(Text.class);
                job.setMapOutputValueClass(IntWritable.class);
                job.setOutputKeyClass(Text.class);
                job.setOutputValueClass(LongWritable.class);
                break;

            case "hourly":
                job.setMapperClass(HourlyActivityJob.HourlyMapper.class);
                job.setReducerClass(HourlyActivityJob.HourlyReducer.class);
                job.setMapOutputKeyClass(Text.class);
                job.setMapOutputValueClass(IntWritable.class);
                job.setOutputKeyClass(Text.class);
                job.setOutputValueClass(LongWritable.class);
                break;

            case "funnel":
                job.setMapperClass(FunnelJob.FunnelMapper.class);
                job.setReducerClass(FunnelJob.FunnelReducer.class);
                job.setMapOutputKeyClass(Text.class);
                job.setMapOutputValueClass(Text.class);
                job.setOutputKeyClass(Text.class);
                job.setOutputValueClass(LongWritable.class);
                break;

            default:
                System.err.println("未知任务: " + task);
                System.err.println("可选: topitems | behavior | hourly | funnel");
                System.exit(1);
                return;
        }

        FileInputFormat.addInputPath(job, new Path(input));
        FileOutputFormat.setOutputPath(job, new Path(output));

        System.exit(job.waitForCompletion(true) ? 0 : 1);
    }
}
