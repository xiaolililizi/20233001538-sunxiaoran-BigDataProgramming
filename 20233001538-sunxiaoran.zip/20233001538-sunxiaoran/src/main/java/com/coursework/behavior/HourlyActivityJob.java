package com.coursework.behavior;

import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;
import org.apache.hadoop.mapreduce.Reducer;

import java.io.IOException;

/**
 * 维度3：每小时活跃度分布
 *
 * 思路：把每条行为按其发生的小时（0-23）归类统计，
 * 用于分析用户一天中哪个时段最活跃（通常晚上 18-22 点是高峰）。
 * Map：  从时间戳算出小时，输出 (小时, 1)
 * Reduce：对每个小时求和
 */
public class HourlyActivityJob {

    public static class HourlyMapper extends Mapper<Object, Text, Text, IntWritable> {
        private static final IntWritable ONE = new IntWritable(1);
        private final Text outKey = new Text();

        @Override
        protected void map(Object key, Text value, Context context)
                throws IOException, InterruptedException {
            BehaviorRecord r = BehaviorRecord.parse(value.toString());
            if (!r.valid) return;
            int hour = r.getHourOfDay();          // 0-23
            // 补零成两位，便于结果按字典序就是按时间序（00,01,...,23）
            outKey.set(String.format("%02d", hour));
            context.write(outKey, ONE);
        }
    }

    public static class HourlyReducer extends Reducer<Text, IntWritable, Text, LongWritable> {
        @Override
        protected void reduce(Text key, Iterable<IntWritable> values, Context context)
                throws IOException, InterruptedException {
            long sum = 0;
            for (IntWritable v : values) sum += v.get();
            context.write(key, new LongWritable(sum));
        }
    }
}
