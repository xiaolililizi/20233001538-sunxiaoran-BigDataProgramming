package com.coursework.behavior;

/**
 * 用户行为记录的解析工具类。
 *
 * 数据集每行格式（逗号分隔）：
 *   用户ID, 商品ID, 商品类目ID, 行为类型, 时间戳
 * 例如：
 *   1,2268318,2520377,pv,1511544070
 *
 * 行为类型(behavior)取值：
 *   pv   - 点击（浏览）
 *   cart - 加入购物车
 *   fav  - 收藏
 *   buy  - 购买
 */
public class BehaviorRecord {

    public String userId;
    public String itemId;
    public String categoryId;
    public String behavior;
    public long timestamp;
    public boolean valid;   // 解析是否成功

    private BehaviorRecord() {}

    /**
     * 解析一行文本为 BehaviorRecord。
     * 解析失败（字段不足、时间戳非数字等）时返回的对象 valid=false，
     * 调用方应据此跳过该行，实现数据清洗。
     */
    public static BehaviorRecord parse(String line) {
        BehaviorRecord r = new BehaviorRecord();
        r.valid = false;

        if (line == null) return r;
        line = line.trim();
        if (line.isEmpty()) return r;

        String[] f = line.split(",");
        // 字段数不足5个，视为脏数据
        if (f.length < 5) return r;

        try {
            r.userId = f[0].trim();
            r.itemId = f[1].trim();
            r.categoryId = f[2].trim();
            r.behavior = f[3].trim();
            r.timestamp = Long.parseLong(f[4].trim());

            // 行为类型必须是已知的四种之一
            if (!r.behavior.equals("pv") && !r.behavior.equals("buy")
                    && !r.behavior.equals("cart") && !r.behavior.equals("fav")) {
                return r;
            }

            r.valid = true;
        } catch (NumberFormatException e) {
            // 时间戳不是数字，脏数据
            return r;
        }
        return r;
    }

    /**
     * 把时间戳（秒）转换为小时（0-23），用于按小时统计活跃度。
     * 数据集时间为北京时间，这里加 8 小时时区偏移后取小时。
     */
    public int getHourOfDay() {
        long beijingSeconds = timestamp + 8 * 3600; // UTC+8
        return (int) ((beijingSeconds % 86400) / 3600);
    }
}
