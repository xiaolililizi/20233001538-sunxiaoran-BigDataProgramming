package com.coursework.behavior;

import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;
import org.apache.hadoop.mapreduce.Reducer;

import java.io.IOException;

/**
 * 维度2：用户行为类型分布
 *
 * 思路：统计 pv / cart / fav / buy 四种行为各自的总次数，
 * 用于分析用户行为构成（点击占比通常远高于购买）。
 * Map：  输出 (行为类型, 1)
 * Reduce：对每种行为类型求和
 */
public class BehaviorDistJob {

    public static class BehaviorDistMapper extends Mapper<Object, Text, Text, IntWritable> {
        private static final IntWritable ONE = new IntWritable(1);
        private final Text outKey = new Text();

        @Override
        protected void map(Object key, Text value, Context context)
                throws IOException, InterruptedException {
            BehaviorRecord r = BehaviorRecord.parse(value.toString());
            if (!r.valid) return;
            outKey.set(r.behavior);   // pv / cart / fav / buy
            context.write(outKey, ONE);
        }
    }

    public static class BehaviorDistReducer extends Reducer<Text, IntWritable, Text, LongWritable> {
        @Override
        protected void reduce(Text key, Iterable<IntWritable> values, Context context)
                throws IOException, InterruptedException {
            long sum = 0;
            for (IntWritable v : values) sum += v.get();
            context.write(key, new LongWritable(sum));
        }
    }
}
