package com.coursework.behavior;

import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;
import org.apache.hadoop.mapreduce.Reducer;

import java.io.IOException;
import java.util.Map;
import java.util.TreeMap;

/**
 * 维度1：热门商品 TOP10
 *
 * 思路：统计每个商品被“点击(pv)”的次数，取次数最多的前10个商品。
 * Map：  输出 (商品ID, 1)，只统计 pv 行为
 * Reduce：先汇总每个商品的总次数，再用一个 TreeMap 维护 TOP10
 *
 * 注意：Reduce 必须设置为 1 个（在 Driver 中 setNumReduceTasks(1)），
 * 否则每个 Reduce 各自取 TOP10，结果不全局。
 */
public class TopItemsJob {

    public static class TopItemsMapper extends Mapper<Object, Text, Text, IntWritable> {
        private static final IntWritable ONE = new IntWritable(1);
        private final Text outKey = new Text();

        @Override
        protected void map(Object key, Text value, Context context)
                throws IOException, InterruptedException {
            BehaviorRecord r = BehaviorRecord.parse(value.toString());
            if (!r.valid) return;                 // 跳过脏数据
            if (!"pv".equals(r.behavior)) return; // 只统计点击行为
            outKey.set(r.itemId);
            context.write(outKey, ONE);
        }
    }

    public static class TopItemsReducer extends Reducer<Text, IntWritable, Text, LongWritable> {
        // TreeMap 按 key（次数）升序排列，始终只保留最大的10个
        private final TreeMap<Long, String> top = new TreeMap<>();

        @Override
        protected void reduce(Text key, Iterable<IntWritable> values, Context context) {
            long sum = 0;
            for (IntWritable v : values) sum += v.get();

            top.put(sum, key.toString());
            // 超过10个就移除次数最小的（TreeMap的第一个）
            if (top.size() > 10) {
                top.remove(top.firstKey());
            }
        }

        @Override
        protected void cleanup(Context context) throws IOException, InterruptedException {
            // 按次数从高到低输出
            for (Map.Entry<Long, String> e : top.descendingMap().entrySet()) {
                context.write(new Text(e.getValue()), new LongWritable(e.getKey()));
            }
        }
    }
}
