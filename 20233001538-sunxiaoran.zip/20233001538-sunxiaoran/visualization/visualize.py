#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
用户行为分析结果可视化脚本

用法：
  1. 先从HDFS把4个分析作业的结果下载到本地 results/ 目录，例如：
       hdfs dfs -get /userbehavior/output/topitems/part-r-00000 results/topitems.txt
       hdfs dfs -get /userbehavior/output/behavior/part-r-00000 results/behavior.txt
       hdfs dfs -get /userbehavior/output/hourly/part-r-00000   results/hourly.txt
       hdfs dfs -get /userbehavior/output/funnel/part-r-00000   results/funnel.txt
  2. 运行本脚本：
       python3 visualize.py
  3. 生成的图片保存在 figures/ 目录，可直接插入报告。

依赖：pip install matplotlib
"""

import os
import matplotlib
matplotlib.use("Agg")  # 无显示环境也能出图
import matplotlib.pyplot as plt

# ---- 中文显示设置（Ubuntu下若无中文字体，见README说明安装）----
plt.rcParams["font.sans-serif"] = ["WenQuanYi Zen Hei", "SimHei", "Microsoft YaHei", "DejaVu Sans"]
plt.rcParams["axes.unicode_minus"] = False

RESULTS_DIR = "results"
FIG_DIR = "figures"
os.makedirs(FIG_DIR, exist_ok=True)

# 行为类型中文名映射
BEHAVIOR_CN = {"pv": "点击", "cart": "加购", "fav": "收藏", "buy": "购买"}


def read_kv(path):
    """读取 MapReduce 输出（key\tvalue 每行），返回 [(key, int_value), ...]"""
    rows = []
    if not os.path.exists(path):
        print(f"[警告] 找不到结果文件: {path}，跳过")
        return rows
    with open(path, encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if not line:
                continue
            parts = line.split("\t")
            if len(parts) != 2:
                parts = line.split()  # 兼容空格分隔
            if len(parts) == 2:
                try:
                    rows.append((parts[0], int(parts[1])))
                except ValueError:
                    pass
    return rows


def plot_top_items():
    """维度1：热门商品TOP10 —— 柱状图"""
    data = read_kv(os.path.join(RESULTS_DIR, "topitems.txt"))
    if not data:
        return
    data = data[:10]
    items = [d[0] for d in data]
    counts = [d[1] for d in data]

    plt.figure(figsize=(10, 6))
    bars = plt.bar(range(len(items)), counts, color="#4C72B0")
    plt.xticks(range(len(items)), items, rotation=45, ha="right")
    plt.xlabel("商品ID")
    plt.ylabel("点击次数")
    plt.title("热门商品 TOP10")
    for bar, c in zip(bars, counts):
        plt.text(bar.get_x() + bar.get_width() / 2, bar.get_height(),
                 str(c), ha="center", va="bottom", fontsize=9)
    plt.tight_layout()
    out = os.path.join(FIG_DIR, "fig_top_items.png")
    plt.savefig(out, dpi=150)
    plt.close()
    print(f"已生成: {out}")


def plot_behavior_dist():
    """维度2：用户行为类型分布 —— 饼图"""
    data = read_kv(os.path.join(RESULTS_DIR, "behavior.txt"))
    if not data:
        return
    labels = [BEHAVIOR_CN.get(d[0], d[0]) for d in data]
    sizes = [d[1] for d in data]

    plt.figure(figsize=(8, 8))
    plt.pie(sizes, labels=labels, autopct="%1.1f%%", startangle=90,
            colors=["#4C72B0", "#DD8452", "#55A868", "#C44E52"])
    plt.title("用户行为类型分布")
    plt.axis("equal")
    plt.tight_layout()
    out = os.path.join(FIG_DIR, "fig_behavior_dist.png")
    plt.savefig(out, dpi=150)
    plt.close()
    print(f"已生成: {out}")


def plot_hourly():
    """维度3：每小时活跃度 —— 折线图"""
    data = read_kv(os.path.join(RESULTS_DIR, "hourly.txt"))
    if not data:
        return
    data.sort(key=lambda x: x[0])  # 按小时排序
    hours = [d[0] for d in data]
    counts = [d[1] for d in data]

    plt.figure(figsize=(11, 6))
    plt.plot(hours, counts, marker="o", color="#4C72B0", linewidth=2)
    plt.fill_between(range(len(hours)), counts, alpha=0.1, color="#4C72B0")
    plt.xlabel("小时 (0-23)")
    plt.ylabel("行为次数")
    plt.title("用户每小时活跃度分布")
    plt.grid(True, linestyle="--", alpha=0.5)
    plt.tight_layout()
    out = os.path.join(FIG_DIR, "fig_hourly.png")
    plt.savefig(out, dpi=150)
    plt.close()
    print(f"已生成: {out}")


def plot_funnel():
    """维度4：购买转化漏斗 —— 横向条形图 + 转化率"""
    data = dict(read_kv(os.path.join(RESULTS_DIR, "funnel.txt")))
    if not data:
        return
    # 漏斗顺序：点击 -> 加购 -> 收藏 -> 购买
    order = ["pv", "cart", "fav", "buy"]
    labels, values = [], []
    for b in order:
        if b in data:
            labels.append(BEHAVIOR_CN[b])
            values.append(data[b])

    plt.figure(figsize=(10, 6))
    bars = plt.barh(range(len(labels)), values, color="#55A868")
    plt.yticks(range(len(labels)), labels)
    plt.gca().invert_yaxis()  # 点击在最上方
    plt.xlabel("用户数")
    plt.title("购买转化漏斗（各行为去重用户数）")

    pv = data.get("pv", 0)
    for i, (bar, v) in enumerate(zip(bars, values)):
        rate = f"  ({v/pv*100:.1f}%)" if pv else ""
        plt.text(bar.get_width(), bar.get_y() + bar.get_height() / 2,
                 f"{v}{rate}", va="center", fontsize=10)
    plt.tight_layout()
    out = os.path.join(FIG_DIR, "fig_funnel.png")
    plt.savefig(out, dpi=150)
    plt.close()
    print(f"已生成: {out}")

    # 打印转化率，方便写进报告
    if pv:
        buy = data.get("buy", 0)
        print(f"\n[转化率] 购买用户/点击用户 = {buy}/{pv} = {buy/pv*100:.2f}%")


if __name__ == "__main__":
    print("开始生成可视化图表...\n")
    plot_top_items()
    plot_behavior_dist()
    plot_hourly()
    plot_funnel()
    print(f"\n全部完成！图表已保存到 {FIG_DIR}/ 目录，可直接插入报告。")
