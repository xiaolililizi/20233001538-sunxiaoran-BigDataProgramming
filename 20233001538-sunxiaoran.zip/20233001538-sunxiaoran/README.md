# Hadoop框架下网站用户购物行为分析的设计与实现

基于Hadoop MapReduce对淘宝用户行为数据集进行多维度分析，并用Python可视化。

## 一、数据集获取

**数据集名称**：UserBehavior（阿里巴巴淘宝用户行为数据集）

**下载地址**：阿里云天池 https://tianchi.aliyun.com/dataset/649
（需注册天池账号，免费下载；网上也有百度网盘转存）

**数据格式**：CSV，逗号分隔，每行一条用户行为，5个字段：

| 字段 | 说明 |
|------|------|
| 用户ID | 整数，序列化后的用户ID |
| 商品ID | 整数，序列化后的商品ID |
| 商品类目ID | 整数，商品所属类目 |
| 行为类型 | 字符串，4种：pv(点击)、cart(加购)、fav(收藏)、buy(购买) |
| 时间戳 | 行为发生的Unix时间戳（秒） |

示例行：`1,2268318,2520377,pv,1511544070`

**注意**：原始数据约3.4GB、近1亿条。课程设计无需全量，**建议截取前100万条**即可（约38MB）：
```bash
head -n 1000000 UserBehavior.csv > UserBehavior_1m.csv
```

> 本项目 `sample-data/UserBehavior_sample.csv` 是一份模拟的小样本（3000行，含少量脏数据用于演示清洗），可先用它跑通整个流程，再换成真实数据集。

## 二、项目结构

```
hadoop-userbehavior/
├── pom.xml                          # Maven配置
├── run.sh                           # 一键运行脚本
├── sample-data/
│   └── UserBehavior_sample.csv      # 模拟示例数据（含脏数据）
├── src/main/java/com/coursework/behavior/
│   ├── BehaviorRecord.java          # 数据解析+清洗工具类
│   ├── Driver.java                  # 主驱动（4选1运行）
│   ├── TopItemsJob.java             # 维度1：热门商品TOP10
│   ├── BehaviorDistJob.java         # 维度2：行为类型分布
│   ├── HourlyActivityJob.java       # 维度3：每小时活跃度
│   └── FunnelJob.java               # 维度4：购买转化漏斗
└── visualization/
    └── visualize.py                 # 结果可视化脚本（出4张图）
```

## 三、四个分析维度

| 维度 | 程序 | 分析内容 | 可视化 |
|------|------|---------|--------|
| 1 | topitems | 点击量最高的TOP10商品 | 柱状图 |
| 2 | behavior | pv/cart/fav/buy四种行为占比 | 饼图 |
| 3 | hourly | 一天24小时各时段活跃度 | 折线图 |
| 4 | funnel | 各行为的去重用户数+转化率 | 漏斗条形图 |

每个维度本质是"按某字段分组统计"，与WordCount同源，技术栈统一。

## 四、运行方式

### 环境检查
```bash
java -version      # JDK 8
hadoop version     # Hadoop 3.x
mvn -version       # Maven
jps                # 应能看到 NameNode/DataNode/ResourceManager/NodeManager
```
若 jps 看不到Hadoop进程，先启动：
```bash
start-dfs.sh
start-yarn.sh
```

### 方式一：一键运行（先用示例数据跑通）
```bash
cd hadoop-userbehavior
chmod +x run.sh
./run.sh
```
脚本自动完成：编译 → 上传HDFS → 跑4个作业 → 下载结果 → 出图。

### 方式二：手动分步（便于截图写报告）
```bash
# 1. 打包
mvn clean package

# 2. 上传数据到HDFS
hdfs dfs -mkdir -p /userbehavior/input
hdfs dfs -put sample-data/UserBehavior_sample.csv /userbehavior/input/

# 3. 逐个运行分析作业
JAR=target/hadoop-userbehavior-jar-with-dependencies.jar
hadoop jar $JAR com.coursework.behavior.Driver topitems /userbehavior/input /userbehavior/output/topitems
hadoop jar $JAR com.coursework.behavior.Driver behavior /userbehavior/input /userbehavior/output/behavior
hadoop jar $JAR com.coursework.behavior.Driver hourly   /userbehavior/input /userbehavior/output/hourly
hadoop jar $JAR com.coursework.behavior.Driver funnel   /userbehavior/input /userbehavior/output/funnel

# 4. 查看结果
hdfs dfs -cat /userbehavior/output/topitems/part-r-00000

# 5. 下载结果并可视化
mkdir -p visualization/results
hdfs dfs -get /userbehavior/output/topitems/part-r-00000 visualization/results/topitems.txt
hdfs dfs -get /userbehavior/output/behavior/part-r-00000 visualization/results/behavior.txt
hdfs dfs -get /userbehavior/output/hourly/part-r-00000   visualization/results/hourly.txt
hdfs dfs -get /userbehavior/output/funnel/part-r-00000   visualization/results/funnel.txt
cd visualization && python3 visualize.py
```

## 五、可视化依赖

```bash
pip install matplotlib
# Ubuntu下若图表中文显示为方框，安装中文字体：
sudo apt-get install fonts-wqy-zenhei
# 然后删除matplotlib字体缓存后重跑：
rm -rf ~/.cache/matplotlib
```

## 六、报告章节对应

| 报告章节 | 对应内容 |
|---------|---------|
| 实验环境 | Hadoop版本、集群模式、JDK/Maven版本 |
| 数据集介绍 | 上面"一、数据集获取"的字段说明、数据量 |
| 数据预处理 | BehaviorRecord.parse() 的清洗逻辑（过滤字段不足、非法行为、空行） |
| 数据存储 | HDFS输入/输出目录结构 |
| 编程实现 | 4个Job的Mapper/Reducer核心代码+解释 |
| 在分布式系统运行 | run.sh执行截图 + YARN(8088端口)监控页面截图 |
| 数据查询 | hdfs dfs -cat 查看各结果截图 |
| 数据可视化 | visualize.py 生成的4张图 + 图表解读 |

## 七、常见问题

- **Output directory already exists**：输出目录不能预先存在，重跑前先删：
  `hdfs dfs -rm -r /userbehavior/output/xxx`
- **ClassNotFoundException**：确认用的是 `-jar-with-dependencies.jar`
- **topitems结果不是全局TOP10**：确认Driver里 `setNumReduceTasks(1)` 没被改动
- **可视化中文乱码**：见"五、可视化依赖"安装字体
- **真实数据集时间范围**：UserBehavior数据集时间在2017年11-12月，时区为北京时间(UTC+8)，代码已做+8小时处理
