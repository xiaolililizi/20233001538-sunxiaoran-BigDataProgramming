#!/bin/bash
# =====================================================================
# 用户购物行为分析 一键运行脚本
# 前置条件：
#   1. Hadoop 已启动（start-dfs.sh / start-yarn.sh，jps 能看到相关进程）
#   2. 已安装 Maven
#   3. 数据文件已准备好（见下方 LOCAL_DATA 变量）
# =====================================================================
set -e

PROJECT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
JAR="$PROJECT_DIR/target/hadoop-userbehavior-jar-with-dependencies.jar"
MAIN="com.coursework.behavior.Driver"

# 本地数据文件（替换成你下载的真实数据集路径；先用示例数据跑通流程也可以）
LOCAL_DATA="$PROJECT_DIR/sample-data/UserBehavior_sample.csv"

HDFS_INPUT="/userbehavior/input"
HDFS_OUT="/userbehavior/output"

echo "===== Step 1: 编译打包 ====="
cd "$PROJECT_DIR"
mvn clean package -q

echo "===== Step 2: 准备HDFS输入目录并上传数据 ====="
hdfs dfs -rm -r -f "$HDFS_INPUT" "$HDFS_OUT" || true
hdfs dfs -mkdir -p "$HDFS_INPUT"
hdfs dfs -put "$LOCAL_DATA" "$HDFS_INPUT/"

echo "===== Step 3: 依次运行4个分析作业 ====="
for task in topitems behavior hourly funnel; do
    echo "----- 运行: $task -----"
    hadoop jar "$JAR" "$MAIN" "$task" "$HDFS_INPUT" "$HDFS_OUT/$task"
done

echo "===== Step 4: 下载结果到本地 visualization/results/ ====="
mkdir -p "$PROJECT_DIR/visualization/results"
hdfs dfs -get -f "$HDFS_OUT/topitems/part-r-00000" "$PROJECT_DIR/visualization/results/topitems.txt"
hdfs dfs -get -f "$HDFS_OUT/behavior/part-r-00000" "$PROJECT_DIR/visualization/results/behavior.txt"
hdfs dfs -get -f "$HDFS_OUT/hourly/part-r-00000"   "$PROJECT_DIR/visualization/results/hourly.txt"
hdfs dfs -get -f "$HDFS_OUT/funnel/part-r-00000"   "$PROJECT_DIR/visualization/results/funnel.txt"

echo "===== Step 5: 查看各分析结果 ====="
for task in topitems behavior hourly funnel; do
    echo "----- $task -----"
    cat "$PROJECT_DIR/visualization/results/$task.txt"
    echo ""
done

echo "===== Step 6: 生成可视化图表 ====="
cd "$PROJECT_DIR/visualization"
python3 visualize.py

echo ""
echo "===== 全部完成！图表在 visualization/figures/，可插入报告 ====="
